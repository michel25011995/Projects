#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

double** Cholesky_Decomposition(double**& matrix, int n)
{
    double temp;
    double sum;

    double** lower = new double* [n];
    for (int i = 0; i < n; i++)
    {
        lower[i] = new double[n];
    }

    // Cholesky decomposition
    for (int j = 0; j < n; j++)
    {
        for (int i = 0; i < n; i++)
        {
            if (i == j)
            {
                sum = 0;
                for (int k = 0; k < i; k++)
                {
                    sum += lower[i][k] * lower[i][k];
                }
                sum = matrix[i][i] - sum;
                lower[i][i] = sqrt((sum));
            }
            else if (j > i)
            {
                sum = 0;
                for (int k = 0; k < i; k++)
                {
                    sum += lower[i][k] * lower[j][k];
                }
                sum = matrix[j][i] - sum;
                lower[j][i] = sum / lower[i][i];
            }
            else
            {
                lower[j][i] = 0;
            }
        }
    }
    return lower;
}

double** readFile(int& n, string fileName)
{
    string line;
    string delimiter = ",";
    size_t pos = 0;
    string num_str;
    vector<double> temp;
    // Open the file to read
    ifstream dataFile(fileName);
    if (dataFile.fail()) {
        cerr << "Error opening file" << endl;
        exit(1);
    }
    cout << "Reading the data" << endl;

    //get data from file and count the number of rows.
    while (getline(dataFile, line))
    {
        n++;
        while ((pos = line.find(delimiter)) != string::npos)
        {
            num_str = line.substr(0, pos);
            //store the data in a temp vector
            temp.push_back(stod(num_str));
            line.erase(0, pos + delimiter.length());
        }

        temp.push_back(stod(line));
    }
    cout << "Finished reading the data" << endl;
    // Create matrix and fill with data
    double** matrix = new double* [n];
    for (int i = 0; i < n; i++) {
        matrix[i] = new double[n];
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            matrix[i][j] = temp[i + j * n];
        }
    }

    return matrix;
}

void saveResults(double** L, int n, string fileName)
{
    cout << "Saving result in " << fileName << endl;
    ofstream output(fileName);
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            output << L[i][j] << ","; // Behaves like cout - also a stream
        }
        output << "\n";
    }
}

int main()
{
    int n = 0;
    double** matrix;
    double** L;

    matrix = readFile(n, "data_10.txt");

    cout << "Starting Cholesky Decomposition..." << endl;

    clock_t start = clock();
    L = Cholesky_Decomposition(matrix, n);

    clock_t end = clock();
    double elapsed_secs = double((end - start) / (double)CLOCKS_PER_SEC);
    cout << "Time to run OUR Cholesky function= " << elapsed_secs << endl;

    saveResults(L, n, "result.txt");

    cout << "Finished" << endl;

    getchar();
    return 0;
}