

import numpy as np
import time
import math

 
def Cholesky_Decomposition(matrix, n):
 
    lower = np.zeros(matrix.shape, float)
    
    for i in range(0,n):
        lower[i,i] = math.sqrt(matrix[i,i] - np.sum(pow(lower[i,:i],2))) # Diagonal value L[k,k]
        for j in range(i+1,n):
            lower[j,i] =(matrix[j,i] - np.sum((lower[i,:i] * lower[j,:i])))  # Sub-column below the diagonal value L[k,k]
        lower[i+1:,i]=lower[i+1:,i] / lower[i,i]
        
        
    
######################################################

print("Read data")
input = np.loadtxt("data_10.txt", delimiter=',')

n = input.shape[0] 
print("our Cholesky decomposition")
t1= time.time()
Cholesky_Decomposition(input, n)
print("Our Cholesky:" + str(time.time()-t1) + " sec")

t2=time.time()
np.linalg.cholesky(input)
print("linalg:" + str(time.time()-t2) + " sec")











